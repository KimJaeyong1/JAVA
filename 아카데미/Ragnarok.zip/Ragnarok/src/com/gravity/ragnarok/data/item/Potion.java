package com.gravity.ragnarok.data.item;

public class Potion {

}
