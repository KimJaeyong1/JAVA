package com.gravity.ragnarok.data.string;

public class Str {
	static public final String CMD_GUIDE_CHARACTER_NAME_INPUT = "케릭터 이름을 입력해주세요";
	static public final String CMD_GUIDE_CHARACTER_GENDER_INPUT = "케릭터 성별을 입력해주세요";
	static public final String CMD_GUIDE_CHARACTER_JOB_INPUT = "케릭터 직업을 입력해주세요";
	static public final String CMD_GUIDE_GAME_OVER_INPUT = "게임 오버!";
}
