package com.gravity.ragnarok.data.img;

public class Entrance {
	static final String ENTRANCE = " *----------------------* \n " + "  RagnaroK Text v0.1.0\n "  + "*----------------------* \n ";
	
	public static void show() {
		System.out.println(ENTRANCE);
	}
}
