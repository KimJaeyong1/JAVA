package com.gravity.ragnarok.data.skill;

public class DoubleAttack {

}
