package com.gravity.ragnarok;

import com.gravity.ragnarok.data.control.Game;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Game game = new Game();
		game.start();
	}
}
