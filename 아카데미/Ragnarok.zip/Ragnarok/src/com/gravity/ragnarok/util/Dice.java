package com.gravity.ragnarok.util;

public class Dice {

}
