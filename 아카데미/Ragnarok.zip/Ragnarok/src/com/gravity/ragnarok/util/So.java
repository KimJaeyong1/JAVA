package com.gravity.ragnarok.util;

public class So {
	public static void pl(String ex) {
		System.out.println(ex);
	}
	
	public static void pl(int ex) {
		System.out.println(ex);
	}
	
	public static void p(String ex) {
		System.out.print(ex);
	}
}
