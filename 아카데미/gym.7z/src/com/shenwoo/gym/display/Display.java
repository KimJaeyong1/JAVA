package com.shenwoo.gym.display;

public class Display {
	void show() {
		
	}
}
