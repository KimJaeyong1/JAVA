package com.shenwoo.gym.display;

public class Title {
	public static final String TITLE = "고양이헬스장 관리 프로그램";
}
